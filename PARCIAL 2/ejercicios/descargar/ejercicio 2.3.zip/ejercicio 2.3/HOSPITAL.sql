create database HOSPITAL;
use HOSPITAL;

Create Table IF NOT EXISTS Medico(
ID_medico char(10) primary key,
ApellidoPater varchar(30) null,
ApellidoMater varchar(30) not null,
Nombre varchar(50)not null,
Fecha_de_titulación datetime(6) not null
);

INSERT INTO Medico (ID_medico, ApellidoPater, ApellidoMater, Nombre, Fecha_de_titulación) VALUES
('1234567890', 'Gonzalez', 'Perez', 'Juan', '2020-06-15 14:30:00');

INSERT INTO Medico (ID_medico, ApellidoMater, Nombre, Fecha_de_titulación) VALUES
('0987654321', 'Lopez', 'Maria', '2022-03-21 09:00:00');

INSERT INTO Medico (ID_medico, ApellidoPater, ApellidoMater, Nombre, Fecha_de_titulación) VALUES
('1122334455', 'Martinez', 'Jimenez', 'Carlos', '2018-12-05 16:45:00');

select * from Medico;

create table if not exists Paciente(
NUmero_ISSSTE char(10) primary key,
RFC char(10) not null,
CURP char(18) not null,
Nombre varchar(50) not null,
APELLIDOPATER varchar(30) not null,
APELLIDOMATER varchar(30) null,
fecha_de_naci datetime(6) not null,
Sexo char(1) not null,
Tipo_sanguineo char(2) not null,
FActor_RH char(1) not null,
Calle varchar(50) not null,
Colonia varchar(50) not null,
Ciudad varchar(50) not null,
CP varchar(5) not null
);

INSERT INTO Paciente (NUmero_ISSSTE, RFC, CURP, Nombre, APELLIDOPATER, APELLIDOMATER, fecha_de_naci, Sexo, Tipo_sanguineo, FActor_RH, Calle, Colonia, Ciudad, CP) VALUES
('1234567890', 'GOFJ890326', 'GOFJ890326MOCRRN00', 'Jorge', 'Flores', 'Jimenez', '1989-03-26 00:00:00', 'M', 'O+', '+', 'Av. Siempre Viva', 'Centro', 'Ciudad de México', '01000');

INSERT INTO Paciente (NUmero_ISSSTE, RFC, CURP, Nombre, APELLIDOPATER, fecha_de_naci, Sexo, Tipo_sanguineo, FActor_RH, Calle, Colonia, Ciudad, CP) VALUES
('0987654321', 'LASR650824', 'LASR650824HFCLNS09', 'Rosa', 'Lara', '1965-08-24 00:00:00', 'F', 'A-', '-', 'Calle Nueva', 'Las Flores', 'Guadalajara', '44200');

INSERT INTO Paciente (NUmero_ISSSTE, RFC, CURP, Nombre, APELLIDOPATER, APELLIDOMATER, fecha_de_naci, Sexo, Tipo_sanguineo, FActor_RH, Calle, Colonia, Ciudad, CP) VALUES
('1112131415', 'MECE801015', 'MECE801015MDFLRN02', 'Eduardo', 'Méndez', 'Cortes', '1980-10-15 00:00:00', 'M', 'AB+', '+', 'Cerrada Olivo', 'Los Pinos', 'Monterrey', '64000');

INSERT INTO Paciente (NUmero_ISSSTE, RFC, CURP, Nombre, APELLIDOPATER, APELLIDOMATER, fecha_de_naci, Sexo, Tipo_sanguineo, FActor_RH, Calle, Colonia, Ciudad, CP) VALUES
('2223242526', 'TOVL931207', 'TOVL931207HPLMNS01', 'Luis', 'Torres', 'Valdez', '1993-12-07 00:00:00', 'M', 'B+', '+', 'Boulevard del Rio', 'La Estancia', 'Puebla', '72500');

INSERT INTO Paciente (NUmero_ISSSTE, RFC, CURP, Nombre, APELLIDOPATER, fecha_de_naci, Sexo, Tipo_sanguineo, FActor_RH, Calle, Colonia, Ciudad, CP) VALUES
('3344556677', 'CAFR540903', 'CAFR540903MMNRLA08', 'Francisco', 'Cano', '1954-09-03 00:00:00', 'M', 'O-', '-', 'Calle del Mar', 'Nueva Era', 'Tijuana', '22000');

select * from Paciente;

create table if not exists Consultas(
ID_Consulta int primary key,
ID_Medico char(10) not null,
Numero_ISSSTE char(10) not null,
Indicaciones text(16) not null,
Fecha datetime(6) null,
foreign key (ID_Medico) references Medico(ID_medico),
foreign key (Numero_ISSSTE) references Paciente(NUmero_ISSSTE)
);

create table if not exists Medicamentos(
ID_Medicamento char(5) primary key,
Nombre varchar(50) not null,
Subtancia varchar(50) not null,
Via_Administracion varchar(50) not null,
Cantidad int not null,
Expediente char(10) not  null,
Indicaciones varchar(50) null,
Contraindicaciones varchar(50) null,
Reacciones varchar(50) not null,
Controlado tinyint(1) not null
);

INSERT INTO Medicamentos (ID_Medicamento, Nombre, Subtancia, Via_Administracion, Cantidad, Expediente, Indicaciones, Contraindicaciones, Reacciones, Controlado) VALUES
('00001', 'Paracetamol', 'Paracetamol', 'Oral', 500, 'EXP001', 'Dolor leve', 'Hipersensibilidad', 'Náuseas', 0);
INSERT INTO Medicamentos (ID_Medicamento, Nombre, Subtancia, Via_Administracion, Cantidad, Expediente, Indicaciones, Contraindicaciones, Reacciones, Controlado) VALUES
('00002', 'Ibuprofeno', 'Ibuprofeno', 'Oral', 400, 'EXP002', 'Dolor moderado', 'Ulceras', 'Dolor abdominal', 0);
INSERT INTO Medicamentos (ID_Medicamento, Nombre, Subtancia, Via_Administracion, Cantidad, Expediente, Indicaciones, Contraindicaciones, Reacciones, Controlado) VALUES
('00003', 'Amoxicilina', 'Amoxicilina', 'Oral', 500, 'EXP003', 'Infección bacteriana', 'Alergia a penicilinas', 'Rash cutáneo', 0);
INSERT INTO Medicamentos (ID_Medicamento, Nombre, Subtancia, Via_Administracion, Cantidad, Expediente, Indicaciones, Contraindicaciones, Reacciones, Controlado) VALUES
('00004', 'Metformina', 'Metformina', 'Oral', 850, 'EXP004', 'Diabetes tipo 2', 'Enfermedad renal', 'Náuseas', 0);
INSERT INTO Medicamentos (ID_Medicamento, Nombre, Subtancia, Via_Administracion, Cantidad, Expediente, Indicaciones, Contraindicaciones, Reacciones, Controlado) VALUES
('00005', 'Loratadina', 'Loratadina', 'Oral', 10, 'EXP005', 'Alergias', null, 'Cefalea', 0);
INSERT INTO Medicamentos (ID_Medicamento, Nombre, Subtancia, Via_Administracion, Cantidad, Expediente, Indicaciones, Contraindicaciones, Reacciones, Controlado) VALUES
('00006', 'Salbutamol', 'Salbutamol', 'Inhalación', 100, 'EXP006', 'Asma', 'Taquicardia', 'Nerviosismo', 0);
INSERT INTO Medicamentos (ID_Medicamento, Nombre, Subtancia, Via_Administracion, Cantidad, Expediente, Indicaciones, Contraindicaciones, Reacciones, Controlado) VALUES
('00007', 'Insulina', 'Insulina', 'Subcutánea', 100, 'EXP007', 'Diabetes', null, 'Hipoglucemia', 1);
INSERT INTO Medicamentos (ID_Medicamento, Nombre, Subtancia, Via_Administracion, Cantidad, Expediente, Indicaciones, Contraindicaciones, Reacciones, Controlado) VALUES
('00008', 'Omeprazol', 'Omeprazol', 'Oral', 20, 'EXP008', 'Acidez', 'Hipersensibilidad', 'Dolor abdominal', 0);
INSERT INTO Medicamentos (ID_Medicamento, Nombre, Subtancia, Via_Administracion, Cantidad, Expediente, Indicaciones, Contraindicaciones, Reacciones, Controlado) VALUES
('00009', 'Diazepam', 'Diazepam', 'Oral', 5, 'EXP009', 'Ansiedad', 'Miastenia gravis', 'Somnolencia', 1);
INSERT INTO Medicamentos (ID_Medicamento, Nombre, Subtancia, Via_Administracion, Cantidad, Expediente, Indicaciones, Contraindicaciones, Reacciones, Controlado) VALUES
('00010', 'Prednisona', 'Prednisona', 'Oral', 5, 'EXP010', 'Inflamación', 'Infecciones', 'Aumento de peso', 0);

select * from Medicamentos;

create table if not exists Detalle_consulta(
ID_consulta int primary key,
ID_Medicamento char(10) not null,
Descripcion text(16) null,
foreign key (ID_consulta) references Consultas(ID_Consulta),
foreign key (ID_Medicamento) references Medicamentos(ID_Medicamento)
);


